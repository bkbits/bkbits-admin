package com.bkbits.admin.controller;

import com.bkbits.admin.mapper.TenantMapper;
import com.bkbits.admin.pojo.IdDTO;
import com.bkbits.admin.pojo.TenantDTO;
import com.bkbits.admin.pojo.TenantVO;
import com.bkbits.admin.service.TenantService;
import com.bkbits.core.Result;
import cn.dev33.satoken.annotation.SaCheckPermission;
import io.swagger.annotations.ApiOperation;
import org.noear.solon.annotation.Body;
import org.noear.solon.annotation.Controller;
import org.noear.solon.annotation.Get;
import org.noear.solon.annotation.Inject;
import org.noear.solon.annotation.Mapping;
import org.noear.solon.annotation.Param;
import org.noear.solon.annotation.Post;

import java.util.List;

/**
 * 租户控制器。
 */
@Controller
@Mapping("/api/tenant")
public class TenantController {


    @Inject
    private TenantService tenantService;

    /**
     * 新增租户。
     *
     * @param dto 租户输入参数
     * @return 新增后的租户
     */
    @ApiOperation("新增租户")
    @Post
    @Mapping("/add")
    @SaCheckPermission("admin.tenant.add")
    public Result<TenantVO> add(@Body TenantDTO dto) {
        return Result.ok(TenantMapper.INSTANCE.toVO(tenantService.add(TenantMapper.INSTANCE.toEntity(dto))));
    }

    /**
     * 按编号查询租户。
     *
     * @param id 租户编号
     * @return 租户；不存在时返回 null
     */
    @ApiOperation("按编号查询租户")
    @Get
    @Mapping("/getById")
    @SaCheckPermission("admin.tenant.query")
    public Result<TenantVO> getById(@Param("id") String id) {
        return Result.ok(TenantMapper.INSTANCE.toVO(tenantService.getById(id)));
    }

    /**
     * 查询全部租户。
     *
     * @return 租户列表
     */
    @ApiOperation("查询全部租户")
    @Get
    @Mapping("/list")
    @SaCheckPermission("admin.tenant.query")
    public Result<List<TenantVO>> list() {
        return Result.ok(TenantMapper.INSTANCE.toVOList(tenantService.list()));
    }

    /**
     * 更新租户。
     *
     * @param dto 租户输入参数
     * @return 更新后的租户
     */
    @ApiOperation("更新租户")
    @Post
    @Mapping("/update")
    @SaCheckPermission("admin.tenant.update")
    public Result<TenantVO> update(@Body TenantDTO dto) {
        return Result.ok(TenantMapper.INSTANCE.toVO(tenantService.update(TenantMapper.INSTANCE.toEntity(dto))));
    }

    /**
     * 按编号删除租户。
     *
     * @param dto 编号参数
     * @return 操作结果
     */
    @ApiOperation("删除租户")
    @Post
    @Mapping("/remove")
    @SaCheckPermission("admin.tenant.remove")
    public Result<Void> remove(@Body IdDTO dto) {
        tenantService.removeById(dto.getId());
        return Result.ok();
    }
}
