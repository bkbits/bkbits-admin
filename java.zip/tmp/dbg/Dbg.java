package dbg;
import org.noear.solon.Solon;
import org.noear.solon.core.Props;
import org.noear.solon.data.datasource.DsUtils;

public class Dbg {
    public static void main(String[] args) {
        Solon.start(Dbg.class, args, app -> {
            try {
                Props cfg = app.cfg();
                var grouped = cfg.getGroupedProp("");
                System.out.println("grouped size = " + grouped.size());
                grouped.forEach((k, v) -> System.out.println("  entry: " + k + " -> " + v));
                var map = DsUtils.buildDsMap(cfg);
                System.out.println("buildDsMap OK: " + map.keySet());
            } catch (Throwable t) {
                System.out.println("buildDsMap FAILED: " + t);
                t.printStackTrace(System.out);
            }
            System.exit(0);
        });
    }
}
