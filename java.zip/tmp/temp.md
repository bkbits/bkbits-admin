# tmp 临时文件记录

| 文件 | 用途 | 状态 |
| --- | --- | --- |
| tmp/starter-cp.txt | 启动 classpath | 使用中 |
| tmp/startup.log | 启动日志 | 使用中 |
